import FoodItem from "./foodItem.js";

const init = () => {
  doApi();
}

const doApi = async() => {
  let url = "http://localhost:3001/foods";
  let resp = await axios.get(url);
  console.log(resp.data);
  createTable(resp.data);
}

const createTable = (_ar) => {
  _ar.forEach((item,i) => {
    let food = new FoodItem("#id_parent",item,i);
    food.render();
  })
}


init();